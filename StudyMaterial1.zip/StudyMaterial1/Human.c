
#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() {
	printf("\n Balleee Balleee... Oye Hoye!!!");
}

void doBharatNatayam() {
	printf("\nDo Eye and Hand Moments... Baharatnatayaam");
}

void playWithHuman() {
	Human gabbar =  { 420, "Gabbar Singh", doBhangra };
	Human basanti = { 100, "Basanti", doBharatNatayam };

	printf("\n ID: %d", gabbar.id);
	printf("\n Name: %s", gabbar.name);
	gabbar.dance(); // Polymorphic Function

	printf("\n ID: %d", basanti.id);
	printf("\n Name: %s", basanti.name);
	basanti.dance(); // Polymorphic Function
}


int main() {
	playWithHuman();
}


