
package examples;


// WHAT IT IS
//		Set Of Operations
// Communication Protocol 

// Abstract Type
//		Operation = { fly(), saveWorld() }
//		Range = Empty Set ( Phi Set )
interface Superpower {
	fun fly()
	fun saveWorld()
}


// How, When, Which Way, Where...

// Type/ Concrete Types
//		Operation = { fly(), saveWorld() }
//		Range = May Not Empty Set
open class Spiderman {
	open fun fly() 		{ println("Fly Like Spiderman!") 		}
	open fun saveWorld() { println("SaveWorld Like Spiderman!") 	}
}

class BadSuperman : Superpower {
	override fun fly() 		 { println("Fly Like BadSuperman!") 		}
	override fun saveWorld() { println("SaveWorld Like BadSuperman!") 	}
}

// Type Of Type Relationship
// Superman Type
//		Superman Type Is Type Of Superpower Type
class Superman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") 		}
	override fun saveWorld() { println("SaveWorld Like Superman!") 	}
}

class Heman : Superpower {
	override fun fly() 		{ println("Fly Like Heman!") 		}
	override fun saveWorld() { println("SaveWorld Like Heman!") 	}
}

class Wonderwoman : Superpower {
	override fun fly() 		 { println("Fly Like Wonderwoman!") 		}
	override fun saveWorld() { println("SaveWorld Like Wonderwoman!") 	}
}

class HanjumanJi : Superpower {
	override fun fly() 		 { println("Fly Like HanjumanJi!") 		}
	override fun saveWorld() { println("SaveWorld Like HanjumanJi!") 	}
}

// DESIGN 01
// 		Mechanism: Using Inheritance

// Type Of Type Relationship
// class Keyword Creating Human Type
//		Human Type Is Type Of Spiderman Type
class Human : Spiderman() {
	override fun fly() 		{ super.fly() } 		//{ println("Fly Like Human!") 		}
	override fun saveWorld(){ super.saveWorld() }	//{ println("SaveWorld Like Human!") 	}
}

// Composition Is Equivalent To Inheritance
// DESIGN 02
//		Mechanism: Using Composition
class HumanAgain {
	var power: Superman = Superman()
	fun fly() 		{ power.fly() } 		//{ println("Fly Like Human!") 		}
	fun saveWorld() { power.saveWorld() }	//{ println("SaveWorld Like Human!") 	}
}

// DESIGN PRINCIPLE
//		DESIGN TOWARDS ABSTRACT TYPES RATHER THAN TYPES (Concrete)

//	 Corollary
//		DESIGN TOWARDS INTERFACES RATHER THAN CONCRETE CLASSES

//	 Corollary
// 	 	SOLID Practices 
// 				Single Responsibility Practice
// 				Open-Close Practice
//					Classes Are Open Extensions and Close For Modifications
// 				Interface Segeration Practice
// 				Dependency Inversion

// DESIGN PRACTICE
//		Always Prefer Composition Over Inheritance

// STRUCTURAL PARADIGM
//		State First Design

// OBJECT ORIENTED PARADIGAM
//		Behaviour First Design

// BetterHuman Is Polymorphics
// DESIGN 02.1
//		Mechanism: Using Composition

class BetterHuman {
	// power Is Delegate
	// Delegator and Delegate Communicate Using Protocol/Contract
	//		Protocol/Contract Is Implemented Using Abstract Type
	var power: Superpower? = null
	fun fly() 		{ power?.fly() } 		//{ println("Fly Like Human!") 		}
	fun saveWorld() { power?.saveWorld() }	//{ println("SaveWorld Like Human!") 	}

	// fun fly() 		{ if ( power != null) power.fly() else null  } 		//{ println("Fly Like Human!") 		}
	// fun saveWorld() { power?.saveWorld() }	//{ println("SaveWorld Like Human!") 	}
}


fun main() {
	val human = Human()
	human.fly()
	human.saveWorld()

	val humanAgain = HumanAgain()
	humanAgain.fly()
	humanAgain.saveWorld()

	val betterHuman = BetterHuman()
	betterHuman.fly()
	betterHuman.saveWorld()	

	// type mismatch: inferred type is Superman but Superpower? was expected
	betterHuman.power = BadSuperman()
	betterHuman.fly()
	betterHuman.saveWorld()	

	betterHuman.power = Superman()
	betterHuman.fly()
	betterHuman.saveWorld()	

 	// error: type mismatch: inferred type is Wonderwoman but Superpower? was expected
	betterHuman.power = Wonderwoman()
	betterHuman.fly()
	betterHuman.saveWorld()	

	betterHuman.power = Heman()
	
	betterHuman.fly() 		// fly Function Call?
	betterHuman.saveWorld()	// saveWorld Function Call?

	betterHuman.power = HanjumanJi()
	betterHuman.fly()
	betterHuman.saveWorld()	
}

