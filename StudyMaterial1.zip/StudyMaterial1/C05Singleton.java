
final class SingletonNonThreadSafe {
	// Storing Single Instance In Private Variable
    private static SingletonNonThreadSafe instance;
    public String value;

    // Making Constructor Private
    private SingletonNonThreadSafe(String value) {
        // EN: The following code emulates slow initialization.

        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        this.value = value;
    }

    // Creating Class Level Method To Return Instance
    public static SingletonNonThreadSafe getInstance(String value) {
        if (instance == null) {
        	// Creating Instance
            instance = new SingletonNonThreadSafe(value);
        }
        // Returing Single Instance
        return instance;
    }
}

//_________________________________________________________________________
//_________________________________________________________________________

final class SingletonThreadSafe {
    // EN: The field must be declared volatile so that double check lock would
    // work correctly.
    //
    private static volatile SingletonThreadSafe instance;

    public String value;

    private SingletonThreadSafe(String value) {
        this.value = value;
    }

    public static SingletonThreadSafe getInstance(String value) {
        // EN: The approach taken here is called double-checked locking (DCL).
        // It exists to prevent race condition between multiple threads that may
        // attempt to get singleton instance at the same time, creating
        // separate instances as a result.
        //
        // It may seem that having the `result` variable here is completely
        // pointless. There is, however, a very important caveat when
        // implementing double-checked locking in Java, which is solved by
        // introducing this local variable.
        //

        SingletonThreadSafe result = instance;
        if (result != null) {
            return result;
        }
        synchronized(SingletonThreadSafe.class) {
            if (instance == null) {
                instance = new SingletonThreadSafe(value);
            }
            return instance;
        }
    }
}


