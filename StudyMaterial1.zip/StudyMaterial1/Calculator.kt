
package examples


// Function Type
//		(Int, Int) -> Int
fun sum(x: Int, y: Int) : Int { return x + y }
fun sub(x: Int, y: Int) : Int { return x - y }
fun mul(x: Int, y: Int) : Int { return x * y }

// Function Type
//		(Int, Int, Int) -> Int
fun sum3(x: Int, y: Int, z: Int) : Int { return x + y + z }

// DESIGN PRINCIPLE
//		DESIGN TOWARDS ABSTRACT TYPES RATHER THAN TYPES (Concrete)

// Polymorphic
// 		Type Of Type Relations
// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
fun calculator(x: Int, y: Int, operation: (Int, Int) -> Int ): Int {
	return operation( x, y )
}

fun playWithCalculator() {
	var result = 0
	val a = 40
	val b = 20

	result = calculator(a, b, ::sum )
	println("Result : $result")

	result = calculator(a, b, ::sub )
	println("Result : $result")

	// result = calculator(a, b, ::sum3 )
	result = calculator(a, b, ::mul )
	println("Result : $result")
}

fun main() {
	playWithCalculator()
}

