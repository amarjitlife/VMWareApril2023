
#include <stdio.h>
#include <limits.h>

int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }

// 
// Is calculator Polymorphic?
// Polymorphic Function
//		Mechanism: Passing Behaviour To Behaviour
int calculator(int x, int y, int (*operation)(int, int) ) {
	return operation(x, y);
}

void playWithCalculator() {
	int a = 40, b = 20;
	int result = 0;

	result = calculator(a, b, sum);
	printf("\nResult %d", result);

	result = calculator(a, b, sub);
	printf("\nResult %d", result);
}

// #include <limits.h>
signed int summation(signed int si_a, signed int si_b) {
	  signed int sum;
	  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
	      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
	    	/* Handle error */
	  		printf("\nNot Able To Calculate Sum For Given Values");
	  } else {
	    	sum = si_a + si_b;
	  		return sum;
	  }
}

void playWithSum() {
	int a, b, result = 0;

	a = 2147483647;
	b = 1;

	result = sum( a, b );
	printf("\nResult %d", result);

	a = -2147483648;
	b = -1;
	result = sum( a, b );
	printf("\nResult %d", result);
}
// Result -2147483648
// Result 2147483647

// #include <limits.h>
signed int summation(signed int si_a, signed int si_b) {
	  signed int sum;
	  // Closed Inside int Type
	  //	Following Closure Law
	  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
	      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
	    	/* Handle error */
	  		printf("\nNot Able To Calculate Sum For Given Values");
	  } else {
	    	sum = si_a + si_b;
	  		return sum;
	  }
}

int main() {
	// playWithCalculator()
	playWithSum();
}
