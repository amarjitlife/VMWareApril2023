package com.baeldung.adapter;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.StringTokenizer;

// Adapter pattern, which we can review here. 
// Enumeration and Iterator are two related interfaces 
// that are great examples of adapter-adaptee relationships.

// Wrapper/Adapter Classes
public class IteratorAdapter<E> implements Iterator<E> {

    private Enumeration<E> enumeration;

    public IteratorAdapter(Enumeration<E> enumeration) {
        this.enumeration = enumeration;
    }

    @Override
    public boolean hasNext() {
        return enumeration.hasMoreElements();
    }

    @Override
    public E next() {
        return enumeration.nextElement();
    }

}


public class StringTokenizerIteratorAdapter extends StringTokenizer implements Iterator<String> {

    public StringTokenizerIteratorAdapter(final String str, final String delim, final boolean returnDelims) {
        super(str, delim, returnDelims);
    }

    public StringTokenizerIteratorAdapter(final String str, final String delim) {
        super(str, delim);
    }

    public StringTokenizerIteratorAdapter(final String str) {
        super(str);
    }

    @Override
    public boolean hasNext() {
        return hasMoreTokens();
    }

    @Override
    public String next() {
        return nextToken();
    }
}

